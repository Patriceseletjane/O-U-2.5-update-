package com.ou25pro.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 77;
    private EditText resultsInput, oddsInput, bankrollInput;
    private TextView resultView, historyView;
    private SharedPreferences prefs;
    private final int BG = Color.rgb(9, 11, 16), CARD = Color.rgb(20, 25, 35), TEXT = Color.rgb(245,247,250), MUTED = Color.rgb(160,168,180), GREEN = Color.rgb(34,197,94), ORANGE = Color.rgb(245,158,11);

    @Override public void onCreate(Bundle b) { super.onCreate(b); prefs=getSharedPreferences("history",0); showSplash(); }

    private void showSplash(){
        TextView t=new TextView(this); t.setText("OVER 2.5 PRO\n\nFINAL BOSS v4.0\n\nVirtual Football Prediction Assistant"); t.setTextColor(TEXT); t.setTextSize(25); t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setBackgroundColor(BG); setContentView(t);
        t.postDelayed(this::showDashboard,650);
    }

    private TextView tv(String s,float size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(0,8,0,8); return t; }
    private LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(22,18,22,18); l.setBackgroundColor(CARD); return l; }
    private EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(115,125,140)); e.setTextColor(TEXT); e.setTextSize(16); e.setSingleLine(false); e.setPadding(4,8,4,8); e.setInputType(InputType.TYPE_CLASS_TEXT); return e; }

    private void showDashboard(){
        ScrollView sv=new ScrollView(this); sv.setBackgroundColor(BG); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,18,18,28); sv.addView(root);
        TextView title=tv("OVER 2.5 PRO",28,TEXT); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub=tv("FINAL BOSS v4.0  •  Decision-support assistant",14,MUTED); sub.setGravity(Gravity.CENTER); root.addView(sub);

        LinearLayout c=card(); root.addView(c,lp(0,14));
        c.addView(tv("PREVIOUS RESULTS",13,MUTED)); resultsInput=input("Example: 3-1, 2-2, 1-3, 4-0, 2-1"); c.addView(resultsInput);
        c.addView(tv("OVER 2.5 ODDS",13,MUTED)); oddsInput=input("Example: 1.70"); oddsInput.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); c.addView(oddsInput);
        c.addView(tv("BANKROLL (₦)",13,MUTED)); bankrollInput=input("Example: 10000"); bankrollInput.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); c.addView(bankrollInput);
        Button scan=new Button(this); scan.setText("SCAN RESULT SCREENSHOT"); scan.setOnClickListener(v->pickImage()); c.addView(scan,lp(0,8));
        Button analyze=new Button(this); analyze.setText("ANALYZE MATCH"); analyze.setTextColor(Color.WHITE); analyze.setBackgroundColor(Color.rgb(37,99,235)); analyze.setOnClickListener(v->analyze()); c.addView(analyze,lp(0,8));

        LinearLayout out=card(); root.addView(out,lp(0,14)); out.addView(tv("PREDICTION",13,MUTED)); resultView=tv("Enter recent results and odds, then tap ANALYZE MATCH.",18,TEXT); out.addView(resultView);
        LinearLayout hist=card(); root.addView(hist,lp(0,14)); hist.addView(tv("RECENT ANALYSES",13,MUTED)); historyView=tv("No saved analyses yet.",14,MUTED); hist.addView(historyView); renderHistory();
        root.addView(tv("Note: This is a heuristic decision-support tool, not a guarantee of future virtual football outcomes or profit. Use only data you trust and stake responsibly.",12,MUTED),lp(0,14));
        setContentView(sv);
    }
    private LinearLayout.LayoutParams lp(int w,int h){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w==0?LinearLayout.LayoutParams.MATCH_PARENT:w,LinearLayout.LayoutParams.WRAP_CONTENT); p.setMargins(0,h,0,0); return p; }

    private void pickImage(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); try{startActivityForResult(i,PICK_IMAGE);}catch(Exception e){Toast.makeText(this,"Image picker unavailable",Toast.LENGTH_SHORT).show();} }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==PICK_IMAGE&&c==RESULT_OK&&d!=null){ Uri u=d.getData(); Toast.makeText(this,"Screenshot selected. Enter the visible results manually for analysis in this version.",Toast.LENGTH_LONG).show(); }}

    private void analyze(){
        String raw=resultsInput.getText().toString().trim(); double odds=parse(oddsInput.getText().toString()); double bank=parse(bankrollInput.getText().toString());
        ArrayList<Integer> totals=new ArrayList<>(); Matcher m=Pattern.compile("(\\d+)\\s*[-:]\\s*(\\d+)").matcher(raw); while(m.find()) totals.add(Integer.parseInt(m.group(1))+Integer.parseInt(m.group(2)));
        if(totals.isEmpty()){resultView.setText("Please enter at least 3 recent scorelines, e.g. 3-1, 2-2, 1-3."); return;}
        int over=0; int sum=0; for(int x:totals){sum+=x;if(x>=3)over++;} double rate=100.0*over/totals.size(); double avg=(double)sum/totals.size();
        double score=50 + (rate-50)*0.55 + Math.min(15,(avg-2.5)*8); if(odds>1.0) score += Math.max(-8,Math.min(8,(odds-1.7)*10)); score=Math.max(1,Math.min(99,score));
        String signal=score>=70?"LEAN OVER 2.5":score<=45?"WAIT / PASS":"NEUTRAL"; int stake=bank>0?(int)Math.round(bank*0.05):0;
        String s=String.format(Locale.US,"%s\n
Heuristic score: %.0f/100\nRecent Over 2.5 rate: %.0f%% (%d/%d)\nAverage goals: %.2f\nSuggested stake cap: ₦%,d (5%% of bankroll)\n\nThis score is not a probability and is not guaranteed.",signal,score,rate,over,totals.size(),avg,stake);
        resultView.setText(s); saveHistory(signal,score,rate,avg); renderHistory();
    }
    private double parse(String s){try{return Double.parseDouble(s.replace(",",""));}catch(Exception e){return 0;}}
    private void saveHistory(String signal,double score,double rate,double avg){String old=prefs.getString("items",""); String item=String.format(Locale.US,"%s | score %.0f | O2.5 %.0f%% | avg %.2f",signal,score,rate,avg); prefs.edit().putString("items",item+"\n"+old).apply();}
    private void renderHistory(){if(historyView==null)return; String h=prefs.getString("items","").trim(); historyView.setText(h.isEmpty()?"No saved analyses yet.":h);}
}

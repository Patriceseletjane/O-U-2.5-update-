# Over 2.5 Pro — Final Boss v4.0

Android decision-support app for reviewing recent virtual-football scorelines and Over 2.5 odds.

## Build on GitHub
1. Upload the contents of this project to the repository root.
2. Commit to `main`.
3. Open **Actions** → **Build Over 2.5 Pro APK**.
4. Open the successful run and download **Over-2.5-Pro-APK**.
5. The downloaded artifact contains the actual `app-debug.apk`.

This project intentionally uses GitHub Actions' Gradle setup instead of requiring `gradlew`/`gradlew.bat` files in the upload. That avoids the missing-wrapper problem from earlier uploads.

## Features
- Dark mobile UI
- Recent-score analysis
- Over 2.5 hit-rate calculation
- Average-goals calculation
- Heuristic 0–100 score
- LEAN OVER / NEUTRAL / WAIT signal
- 5% bankroll stake cap suggestion
- Saved analysis history
- Screenshot picker for future OCR workflow

## Important
The model is a heuristic decision-support system. It does not guarantee a result, 100% accuracy, or profit. It does not place bets or connect to private bookmaker APIs.

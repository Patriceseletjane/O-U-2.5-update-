# Over 2.5 Pro — Final Boss v4

Android prediction assistant for Over 2.5 goals.

## Included
- Modern dark dashboard
- Previous-results parser
- Over 2.5 odds input
- Bankroll and stake calculator
- Confidence score and signal
- Risk controls
- Prediction history stored locally
- Win/Loss/Push tracking
- Screenshot/image picker with OCR-ready architecture
- No bookmaker login or automatic bet placement
- GitHub Actions debug APK build

## Important
This is a decision-support tool, not a guarantee of future virtual football results or profit. Virtual football outcomes are inherently uncertain.

## Build
The GitHub Actions workflow builds a debug APK and uploads it as an artifact.

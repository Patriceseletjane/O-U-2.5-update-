package com.patricesetletjane.over25pro;

import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends AppCompatActivity {
    EditText resultsInput, oddsInput, bankrollInput;
    TextView resultCard;
    SharedPreferences prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        resultsInput = findViewById(R.id.resultsInput);
        oddsInput = findViewById(R.id.oddsInput);
        bankrollInput = findViewById(R.id.bankrollInput);
        resultCard = findViewById(R.id.resultCard);
        prefs = getSharedPreferences("history", MODE_PRIVATE);

        findViewById(R.id.analyzeButton).setOnClickListener(v -> analyze());
        findViewById(R.id.historyButton).setOnClickListener(v -> showHistory());
    }

    void analyze() {
        String raw = resultsInput.getText().toString().trim();
        double odds = parseDouble(oddsInput.getText().toString(), 1.70);
        double bankroll = parseDouble(bankrollInput.getText().toString(), 10000);

        ArrayList<Integer> totals = new ArrayList<>();
        Matcher m = Pattern.compile("(\d+)\s*[-:]\s*(\d+)").matcher(raw);
        while (m.find()) totals.add(Integer.parseInt(m.group(1)) + Integer.parseInt(m.group(2)));

        if (totals.isEmpty()) {
            resultCard.setText("Enter previous results first, e.g. 3-1, 2-2, 1-3, 4-0, 2-1");
            return;
        }

        int over = 0, recentOver = 0;
        for (int i = 0; i < totals.size(); i++) {
            if (totals.get(i) >= 3) {
                over++;
                if (i >= Math.max(0, totals.size()-3)) recentOver++;
            }
        }

        double rate = (over * 100.0) / totals.size();
        double recentRate = (recentOver * 100.0) / Math.min(3, totals.size());

        double score = 50 + (rate - 50) * 0.55 + (recentRate - 50) * 0.30;
        if (odds >= 1.60 && odds <= 2.10) score += 4;
        if (odds > 2.30) score -= 5;
        score = Math.max(1, Math.min(99, score));

        String signal;
        int color;
        if (score >= 72) { signal = "OVER 2.5 • STRONG"; color = Color.rgb(53,208,127); }
        else if (score >= 62) { signal = "OVER 2.5 • LEAN"; color = Color.rgb(0,212,255); }
        else if (score >= 48) { signal = "WAIT / NO BET"; color = Color.rgb(255,176,32); }
        else { signal = "AVOID OVER 2.5"; color = Color.rgb(255,92,92); }

        double stakePct = score >= 72 ? 0.05 : score >= 62 ? 0.03 : 0.0;
        double stake = bankroll * stakePct;

        String out = signal + "\n\n"
                + "Confidence: " + Math.round(score) + "%\n"
                + "Historical Over 2.5: " + String.format(Locale.US, "%.1f%%", rate) + "\n"
                + "Recent 3 Over 2.5: " + String.format(Locale.US, "%.1f%%", recentRate) + "\n"
                + "Odds: " + String.format(Locale.US, "%.2f", odds) + "\n"
                + "Suggested stake: ₦" + String.format(Locale.US, "%.0f", stake) + "\n\n"
                + "This is a heuristic score, not a guarantee.";

        resultCard.setText(out);
        resultCard.setTextColor(color);

        String history = new Date() + " | " + signal + " | " + Math.round(score) + "% | odds " + odds + "\n";
        prefs.edit().putString("log", history + prefs.getString("log", "")).apply();
    }

    void showHistory() {
        String log = prefs.getString("log", "");
        if (log.isEmpty()) log = "No prediction history yet.";
        new AlertDialog.Builder(this).setTitle("Prediction History")
                .setMessage(log).setPositiveButton("Close", null).show();
    }

    double parseDouble(String s, double fallback) {
        try { return Double.parseDouble(s); } catch (Exception e) { return fallback; }
    }
}
